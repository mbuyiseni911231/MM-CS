export default function Home() {
  return (
    <div className="min-h-screen bg-white text-gray-800">
      <header className="bg-green-700 text-white p-6 shadow-md">
        <h1 className="text-3xl font-bold">MM CS Group (Eikenhof Agripark)</h1>
        <p className="text-lg">Vegetable Farmers in Eikenhof, Johannesburg</p>
      </header>
      <section className="p-10 bg-green-100 text-center">
        <h2 className="text-4xl font-bold mb-4">Growing Food, Growing Communities</h2>
        <p className="text-lg max-w-2xl mx-auto mb-6">
          MM CS Group (Eikenhof Agripark) is a black-owned vegetable farming initiative proudly supported by the City of Johannesburg’s Food Resilience Program. We empower black farmers, promote agricultural education, and support healthy meals for schools. This initiative is specifically designed for small-scale farms.
        </p>
        <div className="flex justify-center gap-4 mb-6">
          <a href="https://wa.me/27719159127" className="bg-green-700 text-white px-6 py-3 rounded-lg shadow hover:bg-green-800 transition">WhatsApp Us</a>
          <a href="tel:+27719159127" className="bg-green-700 text-white px-6 py-3 rounded-lg shadow hover:bg-green-800 transition">Call Us</a>
        </div>
      </section>
    </div>
  );
}